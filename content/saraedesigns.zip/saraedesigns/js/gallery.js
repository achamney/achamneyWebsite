require(['/quickforms/js/quickforms.js'],function(){
	quickforms.registerReadyFunction(function(){
		require(['/quickforms/js/jquery/jquery-ui-1.10.3.custom.min.js','dom/navControl'],function(){
			quickforms.loadNav('galleryNav.html','galNav',function(){
				var links = $('#galNav a');
				links.css('width',(100/links.length)+'%');
			});
			quickforms.loadCss('/saraedesigns/css/gallery.css');
			
		});
	});
});