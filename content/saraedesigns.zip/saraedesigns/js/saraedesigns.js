require(['/quickforms/js/quickforms.js'],function(){
	quickforms.registerReadyFunction(function(){
		require(['dom/navControl'],function(){
			quickforms.loadNav('nav.html','nav',function(){
				$('#galleryNav').hover(function(){ // in
						var me = $(this);
						me.append('<a href="AllstateMonctonClaims.html" id="galleryCorperateNav" class="navitemSml">Corporate</a>');
						me.append('<a href="galleryResidential.html" id="galleryResidentialNav" class="navitemSml">Residential</a>');
					},function(){ // out
						var me = $(this);
						$('#galleryCorperateNav').remove();
						$('#galleryResidentialNav').remove();
					});
			});
			$('#gallery td.galContent').css('padding','5px');
			$('#gallery td.galContent').on('click',function(){
				var target = $(this);
				var tcol = target.parent().children().index(target);
				$('#gallery td.galContent').each(function(){
					var me = $(this);
					var col = me.parent().children().index(me);
					if(tcol === col)
						me.animate({width:"80%"},400);
					else
						me.animate({width:"20%"},400);
				});
				
			});
			$('#gallery td.galContent').on('hover',function(){
				var target = $(this);
				var tcol = target.parent().children().index(target);
				$('#gallery tbody td.galContent').each(function(){
					var me = $(this);
					var col = me.parent().children().index(me);
					if(tcol === col)
					{
						me.css('background-color','#CCC');
						me.css('border-style','solid');
						me.css('border-width','1px');
					}
					else
					{
						me.css('background-color','#BBB');
						me.css('border-style','none');
					}
				});
				
			});
		});
	});
})

